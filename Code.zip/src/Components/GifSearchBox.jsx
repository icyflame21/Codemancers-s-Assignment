import React,{useEffect,useState} from "react";
import style from "./GifSearchBox.module.css";

export function GifSearchBox({selectedElem}) {
  const [search, setSearch] = useState("trending");
    const [gifs, setGifs] = useState();

  const api_key = "a7dBnSoTdbFgrKE4VGJzQFhj3LMMxhg8";

  useEffect(() => {
    let id =setTimeout(fetch(`https://api.giphy.com/v1/gifs/search?api_key=${api_key}&q=${search}&limit=20`)
    .then((res) => res.json())
          .then(resData => setGifs(resData)));
          console.log(gifs);
      return ()=>{clearTimeout(id)}
  }, [search])

  const onSelectedGif = (item) => {
      selectedElem(item)
  }

  return (
    <div className={style.main}>
        <div>
            <input type="text" onChange={(e)=>setSearch(e.target.value)} />
        </div>
      <div>
        { gifs ? (
            gifs.data.map((item) => (
                <img key={item.id} src={item.images.downsized.url} alt={item.title} onClick={() => onSelectedGif(item)} />
            ))
        ) : '' }
      </div>
    </div>
  );
}