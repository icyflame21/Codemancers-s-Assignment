import './App.css';
import { UserInput } from './Components/UserInput';

function App() {
  return (
    <div className="App">
     <UserInput/>
    </div>
  );
}

export default App;
